﻿Console.WriteLine("Insira qualquer número abaixo:");
int num = int.Parse(Console.ReadLine());

Console.Clear();

if (num % 2  == 0) {
    Console.WriteLine("O número escolhido é par");
} else {
    Console.WriteLine("O número escolhido é ímpar");
}

//Correto