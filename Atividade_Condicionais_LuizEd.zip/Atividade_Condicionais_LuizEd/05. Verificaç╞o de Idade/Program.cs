﻿Console.WriteLine("Insira sua idade abaixo:");
int num = int.Parse(Console.ReadLine());

Console.Clear();

if (num >= 18) {
    Console.WriteLine("Você é maior de idade.");
} else {
    Console.WriteLine("Você é menor de idade.");
}

//Correto